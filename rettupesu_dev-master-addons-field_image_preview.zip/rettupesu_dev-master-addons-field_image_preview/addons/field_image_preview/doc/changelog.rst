v1.3.1
======
* Changes to category and state add to the message log

v1.3
====
* Added message log

v1.2
====
* Public users can submit feedback on each help page

v1.1
====
* Added file attachment input to submit tick form

v1.0
====
* Initial release